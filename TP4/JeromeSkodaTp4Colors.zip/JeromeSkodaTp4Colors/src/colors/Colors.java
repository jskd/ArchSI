/**
 * TP n°: 4
 * 
 * Titre du TP : TP Servlet Config Context
 *
 * Date : 23/02/2018
 * 
 * Nom  : Skoda
 * Prenom : Jérôme
 *
 * email : contact@jeromeskoda.fr
 * 
 * Remarques :
 */

package colors;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Colors
 */
public class Colors extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String color = this.getInitParameter("color");
		response.getWriter().append("TP4 Jérôme Skoda \n")
		.append("Color: " + color + " \n")
		.append("Served at: " + request.getContextPath());
	}

}
