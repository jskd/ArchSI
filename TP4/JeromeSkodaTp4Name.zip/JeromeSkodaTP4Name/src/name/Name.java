
/**
 * TP n°: 4
 * 
 * Titre du TP : TP Servlet Config Context
 *
 * Date : 23/02/2018
 * 
 * Nom  : Skoda
 * Prenom : Jérôme
 *
 * email : contact@jeromeskoda.fr
 * 
 * Remarques :
 */
package name;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Name
 */
public class Name extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String firstName = this.getInitParameter("firstName");
		String lastName = getServletContext().getInitParameter("lastName");
		
		response.getWriter().append("TP4 Jérôme Skoda \n")
		.append("Nom: " + firstName + " \n")
		.append("Prenom: " + lastName + " \n")
		.append("Served at: " + request.getContextPath());
	}

}
