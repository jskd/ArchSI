/**
 * TP n°: 5
 * 
 * Titre du TP : TP Servlet Context Listener
 *
 * Date : 2/03/2018
 * 
 * Nom  : Skoda
 * Prenom : Jérôme
 *
 * email : contact@jeromeskoda.fr
 * 
 * Remarques :
 */

package jeromeSkodaTP5;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

/**
 * Application Lifecycle Listener implementation class ContextAttributeListener
 *
 */
public class ContextAttributeListener implements ServletContextListener, ServletContextAttributeListener, HttpSessionAttributeListener {

    /**
     * Default constructor. 
     */
    public ContextAttributeListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextAttributeListener#attributeAdded(ServletContextAttributeEvent)
     */
    public void attributeAdded(ServletContextAttributeEvent arg0) {
    	System.out.println("ServletContext attribute added  => "
    			+ "{ " + arg0.getName() + ", " + arg0.getValue() + " }");
    }

	/**
     * @see ServletContextAttributeListener#attributeRemoved(ServletContextAttributeEvent)
     */
    public void attributeRemoved(ServletContextAttributeEvent arg0) {
    	System.out.println("ServletContext attribute removed  => "
    			+ "{ " + arg0.getName() + ", " + arg0.getValue() + " }");
    }

	/**
     * @see ServletContextAttributeListener#attributeReplaced(ServletContextAttributeEvent)
     */
    public void attributeReplaced(ServletContextAttributeEvent arg0) {
    	System.out.println("ServletContext attribute replaced  => "
    			+ "{ " + arg0.getName() + ", " + arg0.getValue() + " }");
    }

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
    	System.out.println("ServletContext context destroyed   => "
    			+ "{ " + arg0.getServletContext() + " }");
		
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
    	System.out.println("ServletContext context initialized  => "
    			+ "{ " + arg0.getServletContext() + " }");
	}

	@Override
	public void attributeAdded(HttpSessionBindingEvent arg0) {
    	System.out.println("HTTP Session attribute added  => "
    			+ "{ " + arg0.getName() + ", " + arg0.getValue() + " }");
	}

	@Override
	public void attributeRemoved(HttpSessionBindingEvent arg0) {
    	System.out.println("HTTP Session attribute removed  => "
    			+ "{ " + arg0.getName() + ", " + arg0.getValue() + " }");
	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent arg0) {
    	System.out.println("HTTP Session attribute replaced  => "
    			+ "{ " + arg0.getName() + ", " + arg0.getValue() + " }");		
	}
	
}
