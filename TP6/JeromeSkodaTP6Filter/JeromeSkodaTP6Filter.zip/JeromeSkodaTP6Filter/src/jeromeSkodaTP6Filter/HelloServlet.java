/**
 * TP n°: 6
 * 
 * Titre du TP : TP Filter
 *
 * Date : 9/03/2018
 * 
 * Nom  : Skoda
 * Prenom : Jérôme
 *
 * email : contact@jeromeskoda.fr
 * 
 * Remarques :
 */

package jeromeSkodaTP6Filter;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet
 */
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("TP6 Jérôme Skoda \n")
		.append("Served at: " + request.getContextPath());
	}

}
