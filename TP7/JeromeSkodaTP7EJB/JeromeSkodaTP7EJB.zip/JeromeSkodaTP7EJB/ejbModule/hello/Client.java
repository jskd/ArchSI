package hello;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.util.Hashtable;

public class Client {
	
	public static void main(String[] args) throws NamingException {
		 
        final Hashtable<String, String> jndiProperties = new Hashtable<String, String>();
        
        jndiProperties.put(Context.INITIAL_CONTEXT_FACTORY, "org.wildfly.naming.client.WildFlyInitialContextFactory");
        jndiProperties.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
        
        final Context ctx = new InitialContext(jndiProperties);

		Object obj = ctx.lookup("JeromeSkodaTP7EJB/HelloBean!hello.HelloRemote");

		System.out.println("Jerome Skoda - TP7 EJB");
		
		System.out.println("Lookup retourned: " + obj);
		
		HelloRemote hello = (HelloRemote) obj;
		
		String s = hello.echo("Hello EJB3");
		System.out.println("echo returned: " + s);
				
	}

}
