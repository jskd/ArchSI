package hello;

import javax.ejb.*;

@Stateless
public class HelloBean implements HelloRemote {
	
	public String echo(String s) {
		System.out.println("HelloEcho = " + s);
		return s;
	}

}
