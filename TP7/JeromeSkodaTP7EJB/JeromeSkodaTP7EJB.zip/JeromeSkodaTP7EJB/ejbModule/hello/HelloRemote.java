package hello;

import javax.ejb.*;

@Remote
public interface HelloRemote {

	public String echo(String s);

}
