/**
* TP n°: 7 
*
* Titre du TP : JSP
*
* Date : 16/04/2018
*
* Nom : Skoda
* Prenom : Jérôme
*
* email : contact@jeromeskoda.fr
*
* Remarques :
*/

package jeromeSkodaTP7;

public class Person {
	private String firstName = null;
	private String lastName = null;
	
	public Person() {
		
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
