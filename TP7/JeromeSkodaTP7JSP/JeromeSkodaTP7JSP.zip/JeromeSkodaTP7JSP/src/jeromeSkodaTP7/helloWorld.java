/**
* TP n°: 7 
*
* Titre du TP : JSP
*
* Date : 16/04/2018
*
* Nom : Skoda
* Prenom : Jérôme
*
* email : contact@jeromeskoda.fr
*
* Remarques :
*/

package jeromeSkodaTP7;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class helloWorld
 */
public class helloWorld extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		response.setContentType ("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println(
				"<html>"+
						"<head>"+
						"<title>out html</title>"+
						"</head>"+
						"<body>"+
						"<h2>hello</h2>" +
						"world"+
				"<h2>");
		out.print(new java.util.Date() );
		out.println( "</h2>" +
				"</body>"+
				"</html>"
				);

	}

}