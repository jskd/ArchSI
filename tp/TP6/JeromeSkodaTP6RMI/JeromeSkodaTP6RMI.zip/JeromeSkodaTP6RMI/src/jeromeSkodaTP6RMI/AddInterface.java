/**
 * TP n°: 6
 * 
 * Titre du TP : TP RMI
 *
 * Date : 9/03/2018
 * 
 * Nom  : Skoda
 * Prenom : Jérôme
 *
 * email : contact@jeromeskoda.fr
 * 
 * Remarques :
 */

package jeromeSkodaTP6RMI;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface AddInterface extends Remote{
	public int add(int nb1, int nb2) throws RemoteException;
}
