/**
 * TP n°: 6
 * 
 * Titre du TP : TP RMI
 *
 * Date : 9/03/2018
 * 
 * Nom  : Skoda
 * Prenom : Jérôme
 *
 * email : contact@jeromeskoda.fr
 * 
 * Remarques :
 */

package jeromeSkodaTP6RMI;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {

	final static int _port = 6667;
	
	public static void main(String[] argv) {
		
		try {

			Registry registry = LocateRegistry.getRegistry(_port);
			AddInterface stub = (AddInterface) registry.lookup("Add");
			System.out.println("Jerome Skoda TP6 RMI");
			System.out.println(stub.add(1, 2));

		} catch (Exception e) { 
			e.printStackTrace(); 
		}

	}
}
