/**
 * TP n°: 6
 * 
 * Titre du TP : TP RMI
 *
 * Date : 9/03/2018
 * 
 * Nom  : Skoda
 * Prenom : Jérôme
 *
 * email : contact@jeromeskoda.fr
 * 
 * Remarques :
 */

package jeromeSkodaTP6RMI;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server {

	final static int _port = 6667;
	
	public static void main(String[] argv) {
		try {

			AddInterface skeleton = (AddInterface) UnicastRemoteObject.exportObject(
					new AddImplementation(), 0
			);
			Registry registry = LocateRegistry.createRegistry(_port);
			registry.rebind("Add", skeleton);
			System.out.println("Jerome Skoda TP6 RMI");
			System.out.println("Server ready");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
